#include"box.h"
#include<iostream>


box::box():length(0),breadth(0),height(0) {}
box::box(int a,int b,int c):length(a),breadth(b),height(c) {}
box::box(const box& ref):length(ref.length),breadth(ref.breadth),height(ref.height) {}

int box:: getlength() const {
    return length;
}

int box:: getbreadth() const {
    return breadth;
}

int box:: getheight() const {
    return height;
}

int box:: getvolume() const {
    return length*breadth*height;
}
void box:: display() const {

    std::cout<<"Length:"<<length<<" "<<"Breadth:"<<breadth<<" "<<"Height:"<<height;
}




