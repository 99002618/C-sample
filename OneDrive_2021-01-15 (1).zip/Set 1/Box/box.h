#ifndef __BOX_H
#define __BOX_H

#include<string>

class box {

    int length,breadth,height;

  public:
    box();
    explicit box(int,int,int);
    explicit box(int);
    box(const box&);
    int getlength() const;
    int getbreadth() const;
    int getheight() const;
    int getvolume() const;
    void display() const;
};
#endif
