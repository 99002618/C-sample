#include "box.h"
#include <gtest/gtest.h>

TEST(box,DefaultConstructor) {
    box a1;
    EXPECT_EQ(0,a1.getlength());
    EXPECT_EQ(0,a1.getbreadth());
    EXPECT_EQ(0,a1.getheight());


}
TEST(box,ParameterizedConstructor) {
    box a1(10,20,30);
    EXPECT_EQ(10,a1.getlength());
    EXPECT_EQ(20,a1.getbreadth());
    EXPECT_EQ(30,a1.getheight());

}

TEST(box,CopyConstructor) {
    box a1(1,2,3);
    box a2(a1);
    EXPECT_EQ(1,a2.getlength());
    EXPECT_EQ(2,a2.getbreadth());
    EXPECT_EQ(3,a2.getheight());

}
TEST(box,getvolume) {
    box a1(3,2,1);
    box a2(a1);
    EXPECT_EQ(6,a2.getvolume());
}

TEST(box,DisplayTest) {
    box a1(8,6,4);
    std::string ExpectedOut="Length:8 Breadth:6 Height:4";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}

