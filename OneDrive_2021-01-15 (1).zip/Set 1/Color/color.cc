#include "color.h"
#include<iostream>
using namespace std;
Color Color::invert() {
    int r=255,g=255,b=255;
    r-=mr;
    g-=mg;
    b-=mb;
    return Color(r,b,g);
}
void Color::display() {

    std::cout<<mr<<","<<mg<<","<<mb<<endl;

}
Color::Color(color_type a) {
    switch(a) {
    case RED:
        mr=255;
        mg=0;
        mb=0;
        break;
    case BLUE:
        mr=0;
        mg=0;
        mb=255;
        break;
    case GREEN:
        mr=0;
        mg=255;
        mb=0;
        break;
    case GREY:
        mr=128;
        mg=128;
        mb=128;
        break;
    case WHITE:
        mr=255;
        mg=255;
        mb=255;
        break;
    }
}
Color::Color():mr(0),mg(0),mb(0) {}
Color::Color(int r,int g,int b):mr(r),mg(g),mb(b) {}
Color::Color(int a):mr(a),mg(a),mb(a) {}

int Color::getr() {
    return mr;
}

int Color::getg() {
    return mg;
}

int Color::getb() {
    return mb;
}
