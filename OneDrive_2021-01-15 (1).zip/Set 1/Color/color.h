#ifndef __ACCOUNT_H
#define __ACCOUNT_H
enum color_type {
    RED=0,
    BLUE,
    GREEN,
    WHITE,
    GREY
};
class Color {
    int mr,mg,mb;
  public:
    Color();
    explicit Color(int);
    explicit Color(color_type);
    Color (int,int,int);
    Color invert();
    void display();
    int getr();
    int getg();
    int getb();
};

#endif

