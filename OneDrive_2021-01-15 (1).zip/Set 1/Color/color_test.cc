#include <gtest/gtest.h>
#include "color.h"

TEST(Color,DefaultConstructor) {
    Color c1;
    EXPECT_EQ(0,c1.getr());
    EXPECT_EQ(0,c1.getg());
    EXPECT_EQ(0,c1.getb());

}
TEST(Color,ParameterizedConstructor) {
    Color a1(10,20,30);
    EXPECT_EQ(10,a1.getr());
    EXPECT_EQ(20,a1.getg());
    EXPECT_EQ(30,a1.getb());

}
TEST(Color,EnumeratorConstructor) {
    Color a1(RED);
    EXPECT_EQ(255,a1.getr());
    EXPECT_EQ(0,a1.getg());
    EXPECT_EQ(0,a1.getb());

}

TEST(Color,Invert) {
    Color a1(RED);
    Color result=a1.invert();
    EXPECT_EQ(0,result.getr());
    EXPECT_EQ(255,result.getg());
    EXPECT_EQ(255,result.getb());

}
TEST(Color,DisplayTest) {
    Color a1(8,6,4);
    std::string ExpectedOut="8,6,4\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}
/* Color a1;
    a1.display();
    Color invert=a1.invert();
    invert.display();
    Color a2(129);
    a2.display();
    Color a4(10,20,30);
    a4.display();
    Color a5(RED);
    a5.display();*/




