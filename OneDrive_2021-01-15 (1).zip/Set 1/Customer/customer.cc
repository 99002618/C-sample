#include"customer.h"
#include<string>
#include<iostream>

Customer::Customer():m_custId(""),m_custName(""),m_phone(""),m_balance(0) {}

Customer::Customer(const std::string& a,const std::string& b,const std::string& c,double d):m_custId(a),m_custName(b),m_phone(c),m_balance(d) {}


Customer::Customer(const std::string& a,const std::string& b,const std::string& c):m_custId(a),m_custName(b),m_phone(c),m_balance(0) {}



Customer::Customer(const Customer& ref):m_custId(ref.m_custId),m_custName(ref.m_custName),m_phone(ref.m_phone),m_balance(ref.m_balance) {}

void Customer::display() const {

    std::cout<<"The details of the customer is : "<<m_custId<<"-"<<m_custName<<"-"<<m_phone<<"-"<<m_balance;

}

double Customer::getBalance() const {
    return m_balance;

}

void Customer::credit(double b) {
    m_balance=m_balance+b;

}

void Customer::makeCall(double b) {

    m_balance=m_balance-b;

}
