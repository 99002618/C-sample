#include<string>
#include<iostream>
#ifndef __CUSTOMER_H
#define __CUSTOMER_H

enum AccountType {
    Prepaid,
    Postpaid
};

class Customer {
    std::string m_custId;
    std::string m_custName;
    std::string m_phone;
    double m_balance;
  public:
    Customer();
    Customer(const std::string &,const std::string&,const std::string&,double);
    Customer(const std::string &,const std::string&,const std::string&);
    Customer(const Customer&);
    void credit(double);
    void makeCall(double);
    double getBalance() const;
    void display() const;
    std::string getcust() {
        return m_custId;
    }
    std::string getname() {
        return m_custName;
    }
    std::string getphone() {
        return m_phone;
    }
    double getbalance() {
        return m_balance;
    }
};

#endif
