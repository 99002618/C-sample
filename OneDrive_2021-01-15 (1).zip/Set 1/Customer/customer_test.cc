#include <gtest/gtest.h>
#include"customer.h"

TEST(Customer,DefaultConstructor) {
    Customer a1;
    EXPECT_EQ("",a1.getcust());
    EXPECT_STREQ("",a1.getname().c_str());
    EXPECT_EQ("",a1.getphone());
    EXPECT_EQ(0.0,a1.getbalance());
}

TEST(Customer,ParamConstructor) {
    Customer a1("9900","chethan","99888855",52252.25);
    EXPECT_EQ("9900",a1.getcust());
    EXPECT_STREQ("chethan",a1.getname().c_str());
    EXPECT_EQ("99888855",a1.getphone());
    EXPECT_EQ(52252.25,a1.getbalance());
}

TEST(Customer,ParamOfThreeConstructor) {
    Customer a1("9900","chethan","99888855");
    EXPECT_EQ("9900",a1.getcust());
    EXPECT_STREQ("chethan",a1.getname().c_str());
    EXPECT_EQ("99888855",a1.getphone());
}

TEST(Customer,CopyConstructor) {
    Customer a1("9900","chethan","99888855",52252.25);
    Customer a2(a1);
    EXPECT_EQ("9900",a2.getcust());
    EXPECT_STREQ("chethan",a2.getname().c_str());
    EXPECT_EQ("99888855",a2.getphone());
    EXPECT_EQ(52252.25,a2.getbalance());


}
TEST(Customer,DisplayTest) {
    Customer a1("9900","chethan","99888855",52252.2);
    std::string ExpectedOut="The details of the customer is : 9900-chethan-99888855-52252.2";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}




TEST(Customer,GetBalance) {
    Customer p1("990","chethan","9988855",52262.25);
    Customer p2(p1);
    EXPECT_EQ(52262.25,p2.getBalance());


}
TEST(Customer,Credit) {
    Customer p1("990","chethan","9988855",52262.25);
    Customer p2(p1);
    EXPECT_EQ(52262.25,p2.getBalance());//before credit
    p2.credit(100);
    EXPECT_EQ(52362.25,p2.getBalance());//after credit
}

TEST(Customer,MakeCall) {
    Customer p1("990","chethan","9988855",52262.25);
    Customer p2(p1);
    EXPECT_EQ(52262.25,p2.getBalance());//before call
    p2.makeCall(100);
    EXPECT_EQ(52162.25,p2.getBalance());//after call

}


