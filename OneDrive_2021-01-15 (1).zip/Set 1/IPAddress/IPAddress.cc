#include "IPAddress.h"

//class defenation

IPAddress::IPAddress():ipval("") { }

IPAddress::IPAddress(int a):ipval(std::to_string(a)+"."+std::to_string(a)+"."+std::to_string(a)+"."+std::to_string(a)) {
//std::cout<<ipval;
}

IPAddress::IPAddress(int a,int b,int c,int d):ipval(std::to_string(a)+"."+std::to_string(b)+"."+std::to_string(c)+"."+std::to_string(d)) {
//std::cout<<ipval;
}
std::string IPAddress::ipAddress() {
    return ipval;
}
bool IPAddress::isLoopBack() {
    std::string temp=this->ipval;
    std::string str1="";
    int i=0;
    while(temp[i]!='.') {
        str1+=temp[i];
        i+=1;
    }
    //std::cout<<temp.compare("hello");
    if((stoi(str1))==127) {
        //std::cout<<"true";
        return true;
    } else {
        //std::cout<<"flase";
        return false;
    }
}

IPclass IPAddress::getIPClass() {

    std::string temp=this->ipval;
    std::string str1="";
    int i=0;
    while(temp[i]!='.') {
        str1+=temp[i];
        i+=1;
    }
//std::cout<<str1;
    if(std::stoi(str1)>=1 && std::stoi(str1)<=127) {
        return A;
    } else if(std::stoi(str1)>=128 && std::stoi(str1)<=191) {
        return B;
    } else if(std::stoi(str1)>=192 && std::stoi(str1)<=223) {
        return C;
    } else if(std::stoi(str1)>=224 && std::stoi(str1)<=239) {
        return D;
    } else {
        return E;
    }
}

void IPAddress::display() {
    std::cout<<(this->ipval)<<std::endl;
}
