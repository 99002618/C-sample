#ifndef __IPADDRESS_H
#define __IPADDRESS_H
#include <iostream>

//header
enum IPclass {
    A=0,
    B,
    C,
    D,
    E

};
class IPAddress {
    std::string ipval;
  public:
    IPAddress();
    explicit IPAddress(int);
    IPAddress(int,int,int,int);
    bool isLoopBack();
    IPclass getIPClass();
    void display();
    std::string ipAddress();
};

#endif
