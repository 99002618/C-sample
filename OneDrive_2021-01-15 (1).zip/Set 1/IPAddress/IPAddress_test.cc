#include "IPAddress.h"
#include <gtest/gtest.h>


TEST(IPAddress,DefaultConstructor) {
    IPAddress a1;
    EXPECT_EQ("",a1.ipAddress());
}

TEST(IPAddress,ParameterizedConstructor) {
    IPAddress a1(127,2,3,4);
    EXPECT_EQ("127.2.3.4",a1.ipAddress());

}

TEST(IPAddress,classofip) {

    IPAddress a1(165,23,64,255);
    EXPECT_EQ(B,a1.getIPClass());
}

TEST(IPAddress,isloopback) {

    IPAddress a1(127,23,64,255);
    EXPECT_EQ(true,a1.isLoopBack());
}

TEST(IPAddress,DisplayTest) {
    IPAddress a1(100,26,55,246);
    std::string ExpectedOut="100.26.55.246\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}




