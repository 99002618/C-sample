#include "IPAddress.h"
#include <gtest/gtest.h>

 TEST(ip,DefaultConstructor) {
    ip a1;
    EXPECT_EQ(0,a1.geta());
    EXPECT_EQ(0,a1.getb());
    EXPECT_EQ(0,a1.getc());
    EXPECT_EQ(0,a1.getd());
}

TEST(ip,ParameterizedConstructor) {
    ip a1("127.2.3.4");
    EXPECT_EQ(127,a1.getIP());
}

TEST(ip,classofip)
{
    ip a1("165.23.64.255");
    EXPECT_STREQ("B",a1.getIPClass().c_str());
}

TEST(ip,isloopback)
{
    ip a1("127.23.64.255");
    EXPECT_STREQ("YES",a1.isLoopBack().c_str());
}

TEST(ip,DisplayTest) {
    ip a1("100.26.55.246");
    std::string ExpectedOut="100.26.55.246\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}
