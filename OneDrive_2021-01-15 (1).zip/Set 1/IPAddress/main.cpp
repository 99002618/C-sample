#include "IPAddress.h"

//header


//main
int main()
{
    //IPAddress i1(1);
    //IPAddress i2(127,0,0,1);
    //bool a = i2.isLoopBack();
    //i2.display();
   // std::cout <<std::endl<<a;
   // return 0;


}
