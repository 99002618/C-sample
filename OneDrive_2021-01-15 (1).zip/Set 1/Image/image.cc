#include"image.h"
using namespace std;

image::image():x(0),y(0),width(0),height(0) {}
image::image(int a,int b,int c,int d):x{a},y{b},width{c},height{d} {}
image::image(const image& r):x(r.x),y(r.y),width(r.width),height(r.height) {}

int image::moveimage(int a,int b) {
    x+=a;
    y+=b;
    return x,y;
}
int image::scale(int a) {
    width*=a;
    height*=a;
    return width,height;
}

int image::resizing(int a,int b) {
    width=a;
    height=b;
    return width,height;
}

void image::display() const {
    cout<<"The coordinates of the image is "<<x<<","<<y<<" The image size is "<<width<<"*"<<height<<endl;
}



