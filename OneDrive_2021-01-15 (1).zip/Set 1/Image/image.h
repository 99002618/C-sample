#ifndef __IMAGE_H
#define __IMAGE_H

#include<iostream>


class image{

int x,y,width,height;
public:
    image();
    image(int,int,int,int);
    image(const image&);

    int getx(){return x;}
    int gety(){return y;}
    int getwidth(){return width;}
    int getheight(){return height;}

    int moveimage(int,int);
    int scale(int);
    int resizing(int,int);
    void display() const;
};

#endif
