#include "image.h"
#include <gtest/gtest.h>

TEST(image,DefaultConstructor) {
    image a1;
    EXPECT_EQ(0,a1.getx());
    EXPECT_EQ(0,a1.gety());
    EXPECT_EQ(0,a1.getwidth());
    EXPECT_EQ(0,a1.getheight());

}

TEST(image,ParameterizedConstructor) {
    image a1(1,2,100,200);
    EXPECT_EQ(1,a1.getx());
    EXPECT_EQ(2,a1.gety());
    EXPECT_EQ(100,a1.getwidth());
    EXPECT_EQ(200,a1.getheight());

}

TEST(image,CopyConstructor) {
    image a1(1,2,100,200);
    image a2(a1);
    EXPECT_EQ(1,a2.getx());
    EXPECT_EQ(2,a2.gety());
    EXPECT_EQ(100,a2.getwidth());
    EXPECT_EQ(200,a2.getheight());

}
TEST(image,MoveImage) {
    image a1(1,2,100,200);
    image a2(a1);
    int q=10,w=20;
    EXPECT_EQ((11,22),a2.moveimage(q,w));
    EXPECT_EQ(100,a2.getwidth());
    EXPECT_EQ(200,a2.getheight());

}
TEST(image,ScaleImage) {
    image a1(1,2,100,200);
    image a2(a1);
    int q=10,w=20;
    int a=2;
    EXPECT_EQ((11,22),a2.moveimage(q,w));
    EXPECT_EQ((200,400),a2.scale(a));


}
TEST(image,ResizingImage) {
    image a1(1,2,100,200);
    image a2(a1);
    int q=10,w=20;
    int a=200,b=600;
    EXPECT_EQ((11,22),a2.moveimage(q,w));
    EXPECT_EQ((200,600),a2.resizing(a,b));
    EXPECT_EQ(200,a2.getwidth());
    EXPECT_EQ(600,a2.getheight());

}
TEST(image,DisplayTest) {
    image a1(100,26,55,246);
    std::string ExpectedOut="The coordinates of the image is 100,26 The image size is 55*246\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}



