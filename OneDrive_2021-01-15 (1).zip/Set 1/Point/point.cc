#include "point.h"
#include<iostream>
#include<string>
#include<math.h>


point::point():x(0),y(0) {};
point::point(int a,int b):x(a),y(b) {};
point::point(const point& ref):x(ref.x),y(ref.y) {};

int point::getx() {
    return x;
}

int point::gety() {
    return y;
}


double point::distancefromorigin(int a, int b) {
    return sqrt((a*a)+(b*b));
}

bool point::isorigin(int g,int h) const {
    if (g==0.0&&h==0.0) {
        return true;
    } else {
        return "NO";
    }
}

bool point::isxaxis(int a,int b) const {

    if(a==0.0&&b>=0.0) {
        return true;
    } else {
        return false;
    }
}


bool point::isyaxis(int a,int b) const {

    if(b==0.0&& a>=0.0) {
        return true;
    } else {
        return false;
    }
}
Quadrant point::quadrant(int a,int b) {

    if(a>0&&b>0) {
        return Q1;
    } else  if(a<0&&b>0) {
        return Q2;
    }

    else  if(a<0&&b<0) {
        return Q3;
    }

    else  if(a>0&&b<0) {
        return Q4;
    }

}

void point::display() const {
    std::cout << x << "," << y <<"\n";

}

