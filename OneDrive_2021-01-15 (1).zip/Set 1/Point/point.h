#include<string>
#include<iostream>
using namespace std;
enum Quadrant {
    Q1,
    Q2,
    Q3,
    Q4
};
class point {

    float x,y;

  public:
    point ();
    point (int,int);
    point (const point &);
    int getx();
    int gety();
    double distancefromorigin(int,int);
    Quadrant quadrant(int,int);
    bool isorigin(int,int) const;
    bool isyaxis(int,int) const;
    bool isxaxis(int,int) const;
    void display()const ;


};

