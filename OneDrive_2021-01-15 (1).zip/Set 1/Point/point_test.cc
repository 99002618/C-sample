#include "point.h"
#include <gtest/gtest.h>

TEST(point,DefaultConstructor) {
    point a1;
    EXPECT_EQ(0,a1.getx());
    EXPECT_EQ(0,a1.gety());

}
TEST(point,ParameterizedConstructor) {
    point a1(1,2);
    EXPECT_EQ(1,a1.getx());
    EXPECT_EQ(2.,a1.gety());

}

TEST(point,CopyConstructor) {
    point a1(1001,5000);
    point a2(a1);
    EXPECT_EQ(1001,a2.getx());
    EXPECT_EQ(5000,a2.gety());

}
TEST(point,distanceFromOrigin) {

    point p1(4,3);

    EXPECT_EQ(5,p1.distancefromorigin(4,3));


}
TEST(point,isorigin) {

    point p1(4,3);

    EXPECT_EQ(true,p1.isorigin(4,3));

}
TEST(point,isXaxis) {

    point p1(4,3);

    EXPECT_EQ(true,p1.isxaxis(0.0,3.0));

}

TEST(point,isYaxis) {

    point p1(4.0,3.0);

    EXPECT_EQ(false,p1.isyaxis(0.0,3.0));

}
TEST(point,QuadrantCheck) {

    point p1(4,3);

    EXPECT_EQ(Q1,p1.quadrant(4.0,3.0));
}

TEST(Point,DisplayTest) {
    point a1(1001,5000);
    std::string ExpectedOut="1001,5000\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}

