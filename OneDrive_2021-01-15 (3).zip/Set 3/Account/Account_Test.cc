#include "CreditAccount.h"
#include "SavingsAccount.h"
#include <gtest/gtest.h>

TEST(CreditAccount,Credit)
{
AccountBase *A;
CreditAccount c1("100","chethan",1000);
A=&c1;
A->credit(1000);
A->debit(10000);
EXPECT_EQ(10000,A->getBalance());
}
TEST(SavingsAccount,Debit)
{
AccountBase *A;
SavingsAccount c1("100","chethan",1000);
A=&c1;
A->debit(1000);
A->credit(10000);
EXPECT_EQ(10000,A->getBalance());
EXPECT_STREQ("100",A->getNumber().c_str());
EXPECT_STREQ("chethan",A->getName().c_str());
}
TEST(SavingsAccount,Display)
{
AccountBase *A;
SavingsAccount c1("100","chethan",1000);
A=&c1;
A->debit(1000);
A->credit(10000);
std::string ExpectedOut="Savings Account:100 chethan 10000\n";
testing::internal::CaptureStdout();
A->display();
std::string ActualOut = testing::internal::GetCapturedStdout();
EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}

TEST(CreditAccount,Display)
{
AccountBase *A;
CreditAccount c1("100","chethan",1000);
A=&c1;
A->credit(1000);
A->debit(10000);
std::string ExpectedOut="Credit Account:100 chethan 10000\n";
testing::internal::CaptureStdout();
A->display();
std::string ActualOut = testing::internal::GetCapturedStdout();
EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}

/*
TEST(SavingsAccount,Transaction)
{
SavingsAccount s1("100","chethan",1000);
A=&s1;
s1.debit(1000);
s1.credit(8000);
s1.display();
}
*/


