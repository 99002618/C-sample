#include <iostream>

#include "CreditAccount.h"
CreditAccount::CreditAccount():AccountBase("","",0.0) { }
CreditAccount::CreditAccount(const std::string& num,const std::string& name, double balance):AccountBase(num,name,balance) { }
CreditAccount::CreditAccount(const std::string& num,const std::string& name):AccountBase(num,name,0.0) { }
void CreditAccount::debit(double balance)
{
    setbalance(+balance);
}
void CreditAccount::credit(double balance)
{
    setbalance(-balance);
}
void CreditAccount::display() const
{
    cout<<"Credit Account:";
     std::cout<<AccountBase::getNumber()<<" "<<AccountBase::getName()<<" "<<AccountBase::getBalance()<<std::endl;
}




