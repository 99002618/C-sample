#ifndef CREDITACCOUNT_H_INCLUDED
#define CREDITACCOUNT_H_INCLUDED
#include "Account.h"

class CreditAccount : public AccountBase {
  public:
  CreditAccount();
  CreditAccount(const std::string&,const std::string&,double);
  CreditAccount(const std::string&,const std::string&);
  void debit(double) override;
  void credit(double) override;
  void display() const override;

};


#endif // CREDITACCOUNT_H_INCLUDED
