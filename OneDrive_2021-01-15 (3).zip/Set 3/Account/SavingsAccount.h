#ifndef SAVINGSACCOUNT_H_INCLUDED
#define SAVINGSACCOUNT_H_INCLUDED
#include "Account.h"
#include <iostream>
class SavingsAccount : public AccountBase {
  public:
  SavingsAccount();
  SavingsAccount(const std::string&,const std::string&,double);
  SavingsAccount(const std::string&,const std::string&);
  void debit(double) override;
  void credit(double) override;
  void display() const override;
};
#endif // SAVINGSACCOUNT_H_INCLUDED
